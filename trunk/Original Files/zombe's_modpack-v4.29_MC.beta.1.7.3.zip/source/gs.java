// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.*;
import java.lang.reflect.*;

// EntityPlayer ? search: "humanoid"
public abstract class gs extends ls {

    // ---------------------------------------------------------------------------------------------------------------------------
    protected static boolean zmodmarker = true;
    private static Method flyHandle, flyCancel;
    // moveEntity   : b   ? search: double d9 = 0\.050000000000000003D; - it is in the function
    public final void callSuper(double mx, double my, double mz) { super.b(mx,my,mz); }
    private static void flyInitialize() {
        try {
            Class mod = Class.forName("ZMod");
            flyHandle = mod.getDeclaredMethod("flyHandle", new Class[]{Object.class, Double.TYPE, Double.TYPE, Double.TYPE});
            flyCancel = mod.getDeclaredMethod("flyDickmoveCancel", new Class[]{});
        } catch(Exception whatever) { zmodmarker=false; flyHandle = flyCancel = null; }
    }
    public void b(double mx, double my, double mz) { // ZMod.flyHandle(this,mx,my,mz);
      if(zmodmarker && flyHandle==null) flyInitialize();
      if(flyHandle!=null) try { flyHandle.invoke(null, new Object[]{this, mx, my, mz}); } catch(Exception whatever) { flyHandle = null; callSuper(mx,my,mz); }
      else callSuper(mx,my,mz);
    }

    // this thing is in this class
    public boolean L() { // do we care? (add first variable)
        return !bq && !u && super.L();
    }

    // ... as is this
    public void o() { // first chance to undo the dickmove
        if(zmodmarker && flyCancel==null) flyInitialize(); if(flyCancel!=null) try { flyCancel.invoke(null, new Object[]{}); } catch(Exception whatever) {} // undo.
        if(aI.q == 0 && Y < 20 && (bt % 20) * 12 == 0)
            c(1);
        c.e();
        h = i;
        super.o();
        float f1 = in.a(aP * aP + aR * aR);
        float f2 = (float)Math.atan(-aQ * 0.20000000298023224D) * 15F;
        if(f1 > 0.1F)
            f1 = 0.1F;
        if(!aX || Y <= 0)
            f1 = 0.0F;
        if(aX || Y <= 0)
            f2 = 0.0F;
        i += (f1 - i) * 0.4F;
        ag += (f2 - ag) * 0.8F;
        if(Y > 0) {
            List list = aI.b(this, aW.b(1.0D, 0.0D, 1.0D));
            if(list != null) {
                for(int i1 = 0; i1 < list.size(); i1++) {
                    sn sn1 = (sn)list.get(i1);
                    if(!sn1.be)
                        j(sn1);
                }

            }
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------


    public gs(fd fd1) {
        super(fd1);
        c = new ix(this);
        f = 0;
        g = 0;
        j = false;
        k = 0;
        z = 20;
        A = false;
        bO = 0;
        D = null;
        d = new aa(c, !fd1.B);
        e = d;
        bf = 1.62F;
        br br1 = fd1.u();
        c((double)br1.a + 0.5D, br1.b + 1, (double)br1.c + 0.5D, 0.0F, 0.0F);
        Y = 20;
        R = "humanoid";
        Q = 180F;
        bu = 20;
        O = "/mob/char.png";
    }

    protected void b() {
        super.b();
        bD.a(16, Byte.valueOf((byte)0));
    }

    public void w_() {
        if(N()) {
            a++;
            if(a > 100)
                a = 100;
            if(!aI.B)
                if(!am())
                    a(true, true, false);
                else
                if(aI.f())
                    a(false, true, true);
        } else
        if(a > 0) {
            a++;
            if(a >= 110)
                a = 0;
        }
        super.w_();
        if(!aI.B && e != null && !e.b(this)) {
            r();
            e = d;
        }
        o = r;
        p = s;
        q = t;
        double d1 = aM - r;
        double d2 = aN - s;
        double d3 = aO - t;
        double d4 = 10D;
        if(d1 > d4)
            o = r = aM;
        if(d3 > d4)
            q = t = aO;
        if(d2 > d4)
            p = s = aN;
        if(d1 < -d4)
            o = r = aM;
        if(d3 < -d4)
            q = t = aO;
        if(d2 < -d4)
            p = s = aN;
        r += d1 * 0.25D;
        t += d3 * 0.25D;
        s += d2 * 0.25D;
        a(jl.k, 1);
        if(aH == null)
            bN = null;
    }

    protected boolean y() {
        return Y <= 0 || N();
    }

    protected void r() {
        e = d;
    }

    public void u_() {
        n = (new StringBuilder()).append("http://s3.amazonaws.com/MinecraftCloaks/").append(l).append(".png").toString();
        bB = n;
    }

    public void s_() {
        double d1 = aM;
        double d2 = aN;
        double d3 = aO;
        super.s_();
        h = i;
        i = 0.0F;
        j(aM - d1, aN - d2, aO - d3);
    }

    public void t_() {
        bf = 1.62F;
        b(0.6F, 1.8F);
        super.t_();
        Y = 20;
        ad = 0;
    }

    protected void f_() {
        if(j) {
            k++;
            if(k >= 8) {
                k = 0;
                j = false;
            }
        } else {
            k = 0;
        }
        X = (float)k / 8F;
    }

    private void j(sn sn1) {
        sn1.b(this);
    }

    public int C() {
        return g;
    }

    public void b(sn sn1) {
        super.b(sn1);
        b(0.2F, 0.2F);
        e(aM, aN, aO);
        aQ = 0.10000000149011612D;
        if(l.equals("Notch"))
            a(new iz(gm.h, 1), true);
        c.g();
        if(sn1 != null) {
            aP = -in.b(((ac + aS) * 3.141593F) / 180F) * 0.1F;
            aR = -in.a(((ac + aS) * 3.141593F) / 180F) * 0.1F;
        } else {
            aP = aR = 0.0D;
        }
        bf = 0.1F;
        a(jl.y, 1);
    }

    public void c(sn sn1, int i1) {
        g += i1;
        if(sn1 instanceof gs)
            a(jl.A, 1);
        else
            a(jl.z, 1);
    }

    public void D() {
        a(c.a(c.c, 1), false);
    }

    public void a(iz iz1) {
        a(iz1, false);
    }

    public void a(iz iz1, boolean flag) {
        if(iz1 == null)
            return;
        hl hl1 = new hl(aI, aM, (aN - 0.30000001192092896D) + (double)w(), aO, iz1);
        hl1.c = 40;
        float f1 = 0.1F;
        if(flag) {
            float f3 = bs.nextFloat() * 0.5F;
            float f5 = bs.nextFloat() * 3.141593F * 2.0F;
            hl1.aP = -in.a(f5) * f3;
            hl1.aR = in.b(f5) * f3;
            hl1.aQ = 0.20000000298023224D;
        } else {
            float f2 = 0.3F;
            hl1.aP = -in.a((aS / 180F) * 3.141593F) * in.b((aT / 180F) * 3.141593F) * f2;
            hl1.aR = in.b((aS / 180F) * 3.141593F) * in.b((aT / 180F) * 3.141593F) * f2;
            hl1.aQ = -in.a((aT / 180F) * 3.141593F) * f2 + 0.1F;
            f2 = 0.02F;
            float f4 = bs.nextFloat() * 3.141593F * 2.0F;
            f2 *= bs.nextFloat();
            hl1.aP += Math.cos(f4) * (double)f2;
            hl1.aQ += (bs.nextFloat() - bs.nextFloat()) * 0.1F;
            hl1.aR += Math.sin(f4) * (double)f2;
        }
        a(hl1);
        a(jl.v, 1);
    }

    protected void a(hl hl1) {
        aI.b(hl1);
    }

    public float a(uu uu1) {
        float f1 = c.a(uu1);
        if(a(ln.g))
            f1 /= 5F;
        if(!aX)
            f1 /= 5F;
        return f1;
    }

    public boolean b(uu uu1) {
        return c.b(uu1);
    }

    public void a(nu nu1) {
        super.a(nu1);
        sp sp1 = nu1.l("Inventory");
        c.b(sp1);
        m = nu1.e("Dimension");
        u = nu1.m("Sleeping");
        a = nu1.d("SleepTimer");
        if(u) {
            v = new br(in.b(aM), in.b(aN), in.b(aO));
            a(true, true, false);
        }
        if(nu1.b("SpawnX") && nu1.b("SpawnY") && nu1.b("SpawnZ"))
            b = new br(nu1.e("SpawnX"), nu1.e("SpawnY"), nu1.e("SpawnZ"));
    }

    public void b(nu nu1) {
        super.b(nu1);
        nu1.a("Inventory", c.a(new sp()));
        nu1.a("Dimension", m);
        nu1.a("Sleeping", u);
        nu1.a("SleepTimer", (short)a);
        if(b != null) {
            nu1.a("SpawnX", b.a);
            nu1.a("SpawnY", b.b);
            nu1.a("SpawnZ", b.c);
        }
    }

    public void a(lw lw) {
    }

    public void a(int i1, int j1, int k1) {
    }

    public void b(sn sn1, int i1) {
    }

    public float w() {
        return 0.12F;
    }

    protected void E() {
        bf = 1.62F;
    }

    public boolean a(sn sn1, int i1) {
        av = 0;
        if(Y <= 0)
            return false;
        if(N() && !aI.B)
            a(true, true, false);
        if((sn1 instanceof gz) || (sn1 instanceof sl)) {
            if(aI.q == 0)
                i1 = 0;
            if(aI.q == 1)
                i1 = i1 / 3 + 1;
            if(aI.q == 3)
                i1 = (i1 * 3) / 2;
        }
        if(i1 == 0)
            return false;
        Object obj = sn1;
        if((obj instanceof sl) && ((sl)obj).c != null)
            obj = ((sl)obj).c;
        if(obj instanceof ls)
            a((ls)obj, false);
        a(jl.x, i1);
        return super.a(sn1, i1);
    }

    protected boolean F() {
        return false;
    }

    protected void a(ls ls1, boolean flag) {
        if((ls1 instanceof gb) || (ls1 instanceof bp))
            return;
        if(ls1 instanceof gi) {
            gi gi1 = (gi)ls1;
            if(gi1.D() && l.equals(gi1.A()))
                return;
        }
        if((ls1 instanceof gs) && !F())
            return;
        List list = aI.a(gi.class, eq.b(aM, aN, aO, aM + 1.0D, aN + 1.0D, aO + 1.0D).b(16D, 4D, 16D));
        Iterator iterator = list.iterator();
        do {
            if(!iterator.hasNext())
                break;
            sn sn1 = (sn)iterator.next();
            gi gi2 = (gi)sn1;
            if(gi2.D() && gi2.G() == null && l.equals(gi2.A()) && (!flag || !gi2.B())) {
                gi2.b(false);
                gi2.c(ls1);
            }
        } while(true);
    }

    protected void b(int i1) {
        int j1 = 25 - c.f();
        int k1 = i1 * j1 + bO;
        c.e(i1);
        i1 = k1 / 25;
        bO = k1 % 25;
        super.b(i1);
    }

    public void a(sk sk) {
    }

    public void a(az az) {
    }

    public void a(yk yk) {
    }

    public void c(sn sn1) {
        if(sn1.a(this))
            return;
        iz iz1 = G();
        if(iz1 != null && (sn1 instanceof ls)) {
            iz1.a((ls)sn1);
            if(iz1.a <= 0) {
                iz1.a(this);
                H();
            }
        }
    }

    public iz G() {
        return c.b();
    }

    public void H() {
        c.a(c.c, null);
    }

    public double I() {
        return (double)(bf - 0.5F);
    }

    public void J() {
        k = -1;
        j = true;
    }

    public void d(sn sn1) {
        int i1 = c.a(sn1);
        if(i1 > 0) {
            if(aQ < 0.0D)
                i1++;
            sn1.a(this, i1);
            iz iz1 = G();
            if(iz1 != null && (sn1 instanceof ls)) {
                iz1.a((ls)sn1, this);
                if(iz1.a <= 0) {
                    iz1.a(this);
                    H();
                }
            }
            if(sn1 instanceof ls) {
                if(sn1.W())
                    a((ls)sn1, true);
                a(jl.w, i1);
            }
        }
    }

    public void p_() {
    }

    public abstract void v();

    public void b(iz iz1) {
    }

    public void K() {
        super.K();
        d.a(this);
        if(e != null)
            e.a(this);
    }

    public cw b(int i1, int j1, int k1) {
        if(!aI.B) {
            if(N() || !W())
                return cw.e;
            if(aI.t.c)
                return cw.b;
            if(aI.f())
                return cw.c;
            if(Math.abs(aM - (double)i1) > 3D || Math.abs(aN - (double)j1) > 2D || Math.abs(aO - (double)k1) > 3D)
                return cw.d;
        }
        b(0.2F, 0.2F);
        bf = 0.2F;
        if(aI.i(i1, j1, k1)) {
            int l1 = aI.e(i1, j1, k1);
            int i2 = ve.d(l1);
            float f1 = 0.5F;
            float f2 = 0.5F;
            switch(i2) {
            case 0: // '\0'
                f2 = 0.9F;
                break;

            case 2: // '\002'
                f2 = 0.1F;
                break;

            case 1: // '\001'
                f1 = 0.1F;
                break;

            case 3: // '\003'
                f1 = 0.9F;
                break;
            }
            e(i2);
            e((float)i1 + f1, (float)j1 + 0.9375F, (float)k1 + f2);
        } else {
            e((float)i1 + 0.5F, (float)j1 + 0.9375F, (float)k1 + 0.5F);
        }
        u = true;
        a = 0;
        v = new br(i1, j1, k1);
        aP = aR = aQ = 0.0D;
        if(!aI.B)
            aI.y();
        return cw.a;
    }

    private void e(int i1) {
        w = 0.0F;
        y = 0.0F;
        switch(i1) {
        case 0: // '\0'
            y = -1.8F;
            break;

        case 2: // '\002'
            y = 1.8F;
            break;

        case 1: // '\001'
            w = 1.8F;
            break;

        case 3: // '\003'
            w = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2) {
        b(0.6F, 1.8F);
        E();
        br br1 = v;
        br br2 = v;
        if(br1 != null && aI.a(br1.a, br1.b, br1.c) == uu.T.bn) {
            ve.a(aI, br1.a, br1.b, br1.c, false);
            br br3 = ve.f(aI, br1.a, br1.b, br1.c, 0);
            if(br3 == null)
                br3 = new br(br1.a, br1.b + 1, br1.c);
            e((float)br3.a + 0.5F, (float)br3.b + bf + 0.1F, (float)br3.c + 0.5F);
        }
        u = false;
        if(!aI.B && flag1)
            aI.y();
        if(flag)
            a = 0;
        else
            a = 100;
        if(flag2)
            a(v);
    }

    private boolean am() {
        return aI.a(v.a, v.b, v.c) == uu.T.bn;
    }

    public static br a(fd fd1, br br1) {
        cl cl1 = fd1.w();
        cl1.c(br1.a - 3 >> 4, br1.c - 3 >> 4);
        cl1.c(br1.a + 3 >> 4, br1.c - 3 >> 4);
        cl1.c(br1.a - 3 >> 4, br1.c + 3 >> 4);
        cl1.c(br1.a + 3 >> 4, br1.c + 3 >> 4);
        if(fd1.a(br1.a, br1.b, br1.c) != uu.T.bn) {
            return null;
        } else {
            br br2 = ve.f(fd1, br1.a, br1.b, br1.c, 0);
            return br2;
        }
    }

    public float M() {
        if(v != null) {
            int i1 = aI.e(v.a, v.b, v.c);
            int j1 = ve.d(i1);
            switch(j1) {
            case 0: // '\0'
                return 90F;

            case 1: // '\001'
                return 0.0F;

            case 2: // '\002'
                return 270F;

            case 3: // '\003'
                return 180F;
            }
        }
        return 0.0F;
    }

    public boolean N() {
        return u;
    }

    public boolean O() {
        return u && a >= 100;
    }

    public int P() {
        return a;
    }

    public void b(String s1) {
    }

    public br Q() {
        return b;
    }

    public void a(br br1) {
        if(br1 != null)
            b = new br(br1);
        else
            b = null;
    }

    public void a(vr vr) {
        a(vr, 1);
    }

    public void a(vr vr, int i1) {
    }

    protected void R() {
        super.R();
        a(jl.u, 1);
    }

    public void a_(float f1, float f2) {
        double d1 = aM;
        double d2 = aN;
        double d3 = aO;
        super.a_(f1, f2);
        i(aM - d1, aN - d2, aO - d3);
    }

    private void i(double d1, double d2, double d3) {
        if(aH != null)
            return;
        if(a(ln.g)) {
            int i1 = Math.round(in.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(i1 > 0)
                a(jl.q, i1);
        } else
        if(ag()) {
            int j1 = Math.round(in.a(d1 * d1 + d3 * d3) * 100F);
            if(j1 > 0)
                a(jl.m, j1);
        } else
        if(p()) {
            if(d2 > 0.0D)
                a(jl.o, (int)Math.round(d2 * 100D));
        } else
        if(aX) {
            int k1 = Math.round(in.a(d1 * d1 + d3 * d3) * 100F);
            if(k1 > 0)
                a(jl.l, k1);
        } else {
            int l1 = Math.round(in.a(d1 * d1 + d3 * d3) * 100F);
            if(l1 > 25)
                a(jl.p, l1);
        }
    }

    private void j(double d1, double d2, double d3) {
        if(aH != null) {
            int i1 = Math.round(in.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(i1 > 0)
                if(aH instanceof yl) {
                    a(jl.r, i1);
                    if(bN == null)
                        bN = new br(in.b(aM), in.b(aN), in.b(aO));
                    else
                    if(bN.a(in.b(aM), in.b(aN), in.b(aO)) >= 1000D)
                        a(ep.q, 1);
                } else
                if(aH instanceof fz)
                    a(jl.s, i1);
                else
                if(aH instanceof wh)
                    a(jl.t, i1);
        }
    }

    protected void b(float f1) {
        if(f1 >= 2.0F)
            a(jl.n, (int)Math.round((double)f1 * 100D));
        super.b(f1);
    }

    public void a(ls ls1) {
        if(ls1 instanceof gz)
            a(((vr) (ep.s)));
    }

    public int c(iz iz1) {
        int i1 = super.c(iz1);
        if(iz1.c == gm.aP.bf && D != null)
            i1 = iz1.b() + 16;
        return i1;
    }

    public void S() {
        if(z > 0) {
            z = 10;
            return;
        } else {
            A = true;
            return;
        }
    }

    public ix c;
    public dw d, e;
    public byte f;
    public int g, k, m, z;
    public float h, i, w, x, y;
    public boolean j;
    public String l, n;
    public double o, p, q, r, s;
    public double t;
    protected boolean u, A;
    public br v;
    private int a, bO;
    private br b, bN;
    public float B, C;
    public lx D;
}
