
import java.util.Random;

// BlockIce
public final class ZBI extends nk {

    public ZBI() {
        super(79, 67);
        c(0.5F).g(3).a(j).a("ice"); // "ice" * drop the last function.
    }
    
    public int a(Random random) { // only function with random
        return 1;
    }

    public void a(fd fd1, gs gs1, int i1, int j1, int k1, int l1) { // \], 1\); * function in base class
        if(fd1.a(i1, j1 - 1, k1) != 9) // mapGetId
            fd1.c(i1, j1, k1, 0); // search: ???
        super.a(fd1, gs1, i1, j1, k1, l1);
    }

}
