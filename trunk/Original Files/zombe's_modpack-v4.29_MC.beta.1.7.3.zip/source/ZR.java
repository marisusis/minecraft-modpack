import java.util.*;

public final class ZR extends Random {

    public int nextInt(int n) {
        return ZMod.mapRandomHandle(n);
    }

}
