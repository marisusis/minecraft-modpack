Toggle Blocks Configuration
===========================

When Toggle Blocks first loads, it will create several configuration files in .minecraft/mods/ApatheticMods. All of these can be opened and edited with any text editor. The files created are ToggleBlocks.properties and several others in the /ToggleBlocks folder.

ToggleBlocks.properties
=======================
* toggleblockid (Default 121): the Toggle Block's block ID.
--Valid values for block IDs are any untaken IDs <= 255.

* changeblockid (Default 122): the Change Block's block ID.

* maxcbdistance (Default 48): the maximum distance a Change Block can be placed from its owning Toggle Block. 
--The valid range is from 1 to 127.

* moveflintandsteel (Default true): if this is true:
--When switching to Ready mode, the Toggle Block will move any found Flint & Steel inside the Change Blocks to nearby chests if there are any with empty slots.
--When a Change Block needs to use a Flint & Steel, it uses one in the chests without taking it away.

If false, the Toggle Block will use the old behavior by keeping all Flint & Steel inside the Change Blocks and taking any available Flint & Steel from the chests as needed.

* centeritemid (Default 331, Redstone dust): the item to use in the center of each Toggle Block recipe.

* altmedironrecipe (Default false): when true, changes the medium Iron Toggle Block recipe to this (where I = Iron ingot and C = center item):
III
III
ICI

* ignoreemptycb (Default false): when true, ignore empty Change Blocks when checking for errors.

* containercheckradius (Default 2): the default container checking radius for new Toggle Blocks or those converted from before v2.4.
--The valid range is from 0 to 5.

* containerblocks (Default 54): a comma-delimited list of block IDs to use for container checking when searching for items to replenish. These containers will also be used for storing Flint & Steel if moveflintandsteel is true.

* assitantitemid (Default 12100): the item ID for the Toggle Block Assistant Item.
--Valid values are any untaken item IDs from 400 to 31999.

* stacktoggleblocks (Default false): when true, allows Toggle Blocks to stack up to 16. Note that you won't get the center item back when deconstructing or creating a Large Toggle Block from two Medium when this is set to true. Be very careful when changing this setting from true to false, as the center item rules apply and you might lose a whole stack of Toggle Blocks if you're not careful.

ExpectedBlocks.properties
=========================
You shouldn't need to add any entries here as Toggle Blocks automatically picks up expected blocks as they are placed and changed. If for some reason your item isn't being registered, you can manually add it. The entries are formatted like this:

<block or item ID in your inventory>=<one or more block IDs placed in the world>

For instance, the Redstone Repeaters are registered like this:

v--Item ID
356=93, 94
    ^--Block IDs, separated by commas

Note that since Toggle Blocks deals only in items, you should go by the item ID if it's an item that places a block (e.g. doors, bed, cake, etc.).

ItemFlags.properties
====================
If any of your mods' items have special properties, they will have to be added here. Again, go by the item ID. For example, this is the item flags entry for wood doors:

v--Item ID
324=save3, down, double
    ^--Flags

The flags currently in use are:
* save: this saves the bits of metadata for this item. Note that you will not need to save the bits related to:
--Alignment (e.g. furnaces, stairs)
--Type of block (e.g. logs, wool)

If all bits should be saved, then you only need "save". If you only need to save certain bits (e.g. the Redstone Repeater's delay), then put the bit numbers (1 through 4) after "save". For example, cake (item ID 354) uses "save123" to save the lowest 3 bits. Setting this requires some knowledge of binary, and the bits are in this order, respective to the numbers used:

4321

* down: this item is set to be placed downward, regardless of the Change Block's alignment. Use this for items that can only be placed on top of a block (e.g. doors, seeds).

* seeds: this item requires tilled soil below it in order to be placed. This allows the Toggle Block to till the soil prior to item placement if it can. Note that this also automatically sets "down".

* drop: if set, the Toggle Block will not try to place or use this item, and will instead go straight to dropping it.

* double: this item is a double block (e.g. doors, bed). If any of the "save" flags are set, the metadata application will continue to the next block. If the item is set to "down", the metadata application will go up to the next block, otherwise the next block will be that in the Change Block's alignment direction.

Priorities.properties
=====================
If your mod's blocks or items need to be placed before or after other blocks, then put them here. Note that blocks are already sorted by altitude, so if your block or item only needs a block under it, it doesn't have to be added here. The priorities go in this order:

-1: Before everything else. This is used primarily for chests so that the Toggle Block can get items out of it if any are within range.
0: Everything else.
1: -v
2:  --Increasingly higher priorities
3: -^