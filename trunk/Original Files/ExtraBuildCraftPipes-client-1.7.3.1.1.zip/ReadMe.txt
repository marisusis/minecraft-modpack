This mod is an extension of SpaceToad's Buildcraft. You will require Buildcraft-core and buildcraft-transport to work.

You can get buildcraft at http://www.minecraftforum.net/topic/286417-166-buildcraft-1662-pipes-quarry-auto-crafting-and-building/