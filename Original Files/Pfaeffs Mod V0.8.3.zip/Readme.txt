-----------------
Pfaeffs Mod 0.8.3
-----------------
for Minecraft Beta 1.7.3 and ModLoader Beta 1.7.3


Installation:
=========

Place all files inside the "modfiles" folder, into your minecraft.jar.
If you want to be able to adjust Block IDs, you will have to 
copy the "pfaeff" folder into your minecraft directory. 
You can then adjust the IDs by editing the "mod.properties" file.

If you don't want to install certain mods, you can leave the
respective mod files away. Those files are:

mod_Allocator
mod_JumpPad
mod_ChestTrap
mod_Fan

Do not leave away the "mod_Pfaeff" file, because this one is needed
for some of those mods.

New Blocks:
=========

		The Allocator 
		(default Block ID: 104)
		----------------------
		
	Description:

The Allocator sucks in items at the input and throws them out at the output.
If a chest or a dispenser is connected to it, it will be used as input/input.
For a more detailed explanation, have a look at these videos:

http://www.youtube.com/watch?v=jynseKfj-VY
http://www.youtube.com/watch?v=Hhxg7eyBIbw

	Crafting Recipe (for 1 Allocator):

C = Cobblestone
R = Redstone
G = Ingot Gold

CRC
CGC
CRC

		The Jump Pad
		(default Block ID: 105)
		----------------------
		
	Description:

Items and players on it will be thrown in the air.

	Crafting Recipe (for 4 Jump Pads):

S = Slimeball
P = Pressure Plate

S
P

		The Chest Trap
		(default Block ID: 103)
		----------------------
		
	Description:

Like a normal chest, but it will trigger adjecent blocks/redstone and make a click noise when opened.

	Crafting Recipe (for 1 Chest Trap):

C = Chest
R = Redstone

R
C

		The Fan
		(default Block ID: 106/107)
		--------------------------
		
	Description:

A Fan that will continuously push items, when powered by redstone.

	Crafting Recipe (for 1 Fan):

C = Cobblestone
R = Redstone
I = Ingot Iron

CCC
CIC
CRC


Logging:
======

This mod stores several information in a file called "log.txt". This file is located in your Minecraft directory 
under "pfaeff/log.txt". This file can provide useful information if there is a problem with the mod.
If you want to get rid of it, or if it has grown too big, you can just delete it.


Changelog
========

V0.8.3
------

Updated to work with Minecraft Beta 1.7.3

V0.8.2
------

Updated to work with Minecraft Beta 1.7.2

V0.8.1
------

Fixed - Chest Trap working again

V0.8
----

Added - New property to change filter behaviour
Added - Smoke for the Allocator
Fixed - Allocator putting items into non-storage minecarts 
Fixed - Items disappear if they are bundled in stacks and allocator tries to suck them in from the ground
Fixed - Filter of the Allocator does not distinguish between different sub-items (dyes for example)

V0.7
-----

Added - Item Filters for the allocator
Added - properties file allows to deactivate the filter feature
Changed - Made some tweaks to the fan

V0.6
-----

Added - New Block: The Fan
Added - Logging 
Changed - Block IDs are now adjustable using the "mod.properties" file

V0.5
-----

Fixed - Possibility of item duping removed
Fixed - Items with subtypes now work correctly
Added - Support for storage minecarts

V0.4
-----

Fixed - Allocator now works with Large Chest Traps and all
other derivates of the Large Chest.

Changed - Allocators connected to furnaces will only put items in their
input slots and take them from the output (the crafting result).

V0.3
-----

Fixed - Allocator now works with Large Chests.

V0.2
-----

Fixed - Allocator can now be blocked by putting a solid block at the output.
Fixed - Allocators can now stack up to 64 (instead of 63)
Changed - Mods can now be installed separately 
		



