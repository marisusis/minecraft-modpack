Toggle Blocks Configuration
===========================

When Toggle Blocks first loads, it will create several configuration files in .minecraft/mods/ApatheticMods. All of these can be opened and edited with any text editor. The files created are ToggleBlocks.properties and several others in the /ToggleBlocks folder.

ToggleBlocks.properties
=======================
* toggleblockid (Default 121): the Toggle Block's block ID.
--Valid values for block IDs are any untaken IDs <= 255, <= 1023 if you have Minecraft Extended and are using its More Block IDs feature.

* changeblockid (Default 122): the Change Block's block ID.

* maxcbdistance (Default 48): the maximum distance a Change Block can be placed from its owning Toggle Block. 
--The valid range is from 1 to 127.

* moveflintandsteel (Default true): if this is true:
--When switching to Ready mode, the Toggle Block will move any found Flint & Steel inside the Change Blocks to nearby chests if there are any with empty slots.
--When a Change Block needs to use a Flint & Steel, it uses one in the chests without taking it away.

If false, the Toggle Block will use the old behavior by keeping all Flint & Steel inside the Change Blocks and taking any available Flint & Steel from the chests as needed.

* centeritemid (Default 331, Redstone dust): the item to use in the center of each Toggle Block recipe.

* altmedironrecipe (Default false): when true, changes the medium Iron Toggle Block recipe to this (where I = Iron ingot and C = center item):
III
III
ICI

* ignoreemptycb (Default false): when true, ignore empty Change Blocks when checking for errors.

* containercheckradius (Default 2): the default container checking radius for new Toggle Blocks or those converted from before v2.4.
--The valid range is from 0 to 5.

* containerblocks (Default 54): a comma-delimited list of block IDs to use for container checking when searching for items to replenish. These containers will also be used for storing Flint & Steel if moveflintandsteel is true.

* assitantitemid (Default 12100): the item ID for the Toggle Block Assistant Item.
--Valid values are any untaken item IDs from 400 to 31999.

* stacktoggleblocks (Default false): when true, allows Toggle Blocks to stack up to 16. Note that you won't get the center item back when deconstructing or creating a Large Toggle Block from two Medium when this is set to true. Be very careful when changing this setting from true to false, as the center item rules apply and you might lose a whole stack of Toggle Blocks if you're not careful.

Configuration GUI
=================
As of v2.5, you can use the configuration GUI to modify block and item settings in-game. You access it by clicking on the "+" button above any of Toggle Blocks' other GUIs.

1. Click the desired item in the list.
2. Modify settings as detailed below.
3. You can obtain a Toggle Block Scanner (useful for determining save flags) by clicking the "Get Scanner" button, using it as detailed below.
4. Click the "Save" button when done.

REMEMBER: Toggle Blocks deals in items, so if you are setting properties for a block placed by an item (like doors or beds), make sure you select the item.

Expected Blocks
---------------
You shouldn't need to add any entries here as Toggle Blocks automatically picks up expected blocks as they are placed and changed. If for some reason your item isn't being registered, you can manually add it.

1. Click the "Add Blocks" button.
2. Click the blocks you want to add. If you accidentally add an incorrect block, you can click on its entry in the right-hand list to remove it. There is a limit of 5 expected blocks.
3. If you want to force an item to have no expected blocks (used for dyes to prevent bonemeal from adding expected blocks), make sure the list is clear and click "None". The text should change to "Set to None!".
4. Click the "Click When Done" or "Save" button when done.

Item Flags
----------
If any of your mods' items have special properties, they will have to be added here. Again, go by the item ID.

The flags as of v2.6 are:
* Save: this saves the bits of metadata for this item. Note that you will not need to save the bits related to:
--Alignment (e.g. furnaces, stairs)
--Type of block (e.g. logs, wool)

If you don't know the save bits for the respective block or item, you can obtain a Toggle Block Scanner by clicking the "Get Scanner" button, using it as detailed below.

* Place downward: this item is set to be placed downward, regardless of the Change Block's alignment. Use this for items that can only be placed on top of a block (e.g. doors, seeds).

* Requires tilled soil: this item requires tilled soil below it in order to be placed. This allows the Toggle Block to till the soil prior to item placement if it can. Note that this also automatically sets "Place downward".

* Drop as item: if set, the Toggle Block will not try to place or use this item, and will instead go straight to dropping it.

* Double block: this item is a double block (e.g. doors, beds). If any of the "Save" flags are set, the metadata application will continue to the next block. If the item is set to "Place downward", the metadata application will go up to the next block, otherwise the next block will be that in the Change Block's alignment direction.

Priority
--------
If your mod's blocks or items need to be placed before or after other blocks, then put them here. Note that blocks are already sorted by altitude, so if your block or item only needs a block under it, it doesn't have to be added here. The priorities go in this order:

-1: Before everything else. This is used primarily for chests so that the Toggle Block can get items out of it if any are within range.
0: Everything else.
1: -v
2:  --Increasingly higher priorities
3: -^

Toggle Block Scanner
====================
Clicking the "Get Scanner" button will give you a Toggle Block Scanner. Right-click on blocks to add them for scanning (up to 5 can be scanned at once). Alternately, you can right-click at a block from outside its normal activate range. This is useful for blocks that activate on right-click or otherwise cannot be right-clicked normally (e.g. liquids).

The Scanner text shows the block's ID, name, location, and metadata bits that correspond to those in the Configuration GUI (once again, if the block is placed by an item, set the flags on the item itself). You can remove a block from being scanned by any one of the following:

*Right-clicking on that block.
*Destroying the block.
*Clicking "Remove Scanner" in the Configuration GUI.